$length=(($ARGV[0]*3)-1);
print "pos-1";
for($i=2;$i<=$length;$i++)
{
	print "\tpos-",$i;
}
print "\tclass\n";
open(FH1,"combine/features-$ARGV[0]");
while($line=<FH1>)
{
	chomp($line);
	if($line!~/^\t/)
	{
		@arr=split("\t",$line);
		$name=$arr[0];
		print $arr[1];
		for($i=2;$i<scalar@arr;$i++)
		{
			if($name eq $arr[$i])
			{
				#do nothing
			}
			else
			{
				print "\t",$arr[$i];
			}
		}
		print "\tx\n";
	}
}
