print "Contig_ID\tLength\tGroup\tReapr_class\n";
open(FH1,"results_with_groups") || die;
while($line=<FH1>)
{
	chomp($line);
	@arr=split("\t",$line);
	if($line!~/^Contig_ID/)
	{
		open(FH2,"$ARGV[0]/reapr_with_error_contigs") || die;#path to reaprs output
		while($line2=<FH2>)
		{
			chomp($line2);
			if($line2 eq $arr[0])
			{
				print $line,"\tR_positive\n";
				last;
			}
		}close(FH2);
		open(FH2,"$ARGV[0]/reapr_without_error_contigs") || die;#path to reaprs output
		while($line2=<FH2>)
		{
			chomp($line2);
			if($line2 eq $arr[0])
			{
				print $line,"\tR_negative\n";
				last;
			}
		}close(FH2);
	}
}
