$num=$ARGV[0];
for($i=1;$i<=$num;$i++)
{
	print "\t",$i;
}
print "\n";
open(FH1,"$ARGV[1]");
while($line=<FH1>)
{
	chomp($line);
	print $line,"\n";
}
