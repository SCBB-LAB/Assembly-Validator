open(FH1,$ARGV[0]);# sequences-names
while($line=<FH1>)
{
	chomp($line);
	open(FH2,$ARGV[1]);#genome-cov-d-opt.out

	system("grep -w \"$arr[0]\" $ARGV[1] >tmp");
	system("cp tmp intermediate/$arr[0]");
	open(FH3,"tmp");
	$sum=0;
	while($line3=<FH3>)
	{

		chomp($line3);
		@arr2=split("\t",$line3);

		$sum=$sum+$arr2[2];

	}
		$avg=$sum/$arr[1];
		print $arr[0]."\t".$avg."\n";


}
