open(FH1,"lengths_5");
while($line=<FH1>)
{
	chomp($line);
	@arr=split("\t",$line);
	open(out1,">lengths/list.$arr[0]");
	open(FH2,"name-length");
	while($line2=<FH2>)
	{
		chomp($line2);
		@arr2=split("\t",$line2);
		if($arr2[1] eq $arr[0])
		{
			print out1 $arr2[0],"\n";
		}
	}close(FH2);
}close(FH1);
