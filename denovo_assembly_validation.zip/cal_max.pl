#!/usr/bin/perl -w

	use strict;
	use POSIX qw(floor ceil);

	open(FH,"$ARGV[0]");
	open(FHX,"$ARGV[1]");
	open(OUT,">$ARGV[2]");
	my $line_x=<FHX>;
	chomp($line_x);
	my $expr_cov = $line_x;
	my $line;
	my @cov;
	my $total_cov = 0;
	my $avgCov;
	my @norByCov;
	my @norByLen;
	my $cnm = $ARGV[0];

	########### storing the coverage value in an array
	while ($line=<FH>) {
		chomp($line);
		my @temp = split("\t",$line);
#		my @val = split("=",$temp[1]);
#		push(@cov,$val[1]);
		push(@cov,$temp[2]);
	}
	
	my $len = scalar(@cov);             ### length of the contig


	for (my $i = 0; $i < @cov; $i++) {
		$total_cov = $total_cov + $cov[$i];          ####### total coverage 
	}
	
	$avgCov = $total_cov/$len;                         ####### average coverage of the contig
	

	######### normalization by average coverage of contig 
	for (my $i = 0; $i < @cov; $i++ ) {
		my $ratio = $cov[$i]/$avgCov;
		push(@norByCov,$ratio);	
	}

		
	############ normalization by the length of the contig
	for (my $i = 0; $i < @norByCov; $i++) {
		my $ras_len = $norByCov[$i]/$len;
		push(@norByLen,$ras_len);
	}

	########## finding maximas present in the contig
	my $max_ref = &find_maximas(\@norByLen);
	my @maximas = @{$max_ref};

		
	######## finally scaling with normalization by scaling factor and experimental coverage
	my $nor_scal_ref = &scaling_wid_nor(\@maximas,$expr_cov);
	my @norWidScal = @{$nor_scal_ref};
	
	#print OUT  $cnm,"\t";
	for (my $i = 0; $i < @maximas; $i++) {
		#print OUT $i+1,"\t",$maximas[$i],"\n";
		print OUT $i+1,"\t",$maximas[$i]/$expr_cov,"\n";
	}
	

	exit 0;

sub find_maximas 
{
	my @input = @{$_[0]};
	my @max_reco;
	push(@max_reco,0);
	
	for (my $i = 1; $i < @input-1; $i++) {
		if (($input[$i] > $input[$i-1]) && ($input[$i] >= $input[$i+1])) {
			push (@max_reco,1);
		} else {
			push (@max_reco,0);
		}
	}
	push (@max_reco,0);
	return(\@max_reco);
}

sub scaling_wid_nor
{	
	my @data = @{$_[0]};
	my $experiment_cov = $_[1];
	my $ip;
	my $fp;
	my @scaled;

	my $n = scalar(@data);
	my $integer_val = sprintf("%1.3f", $n/100);
	($ip, $fp) = split(/\./, $integer_val);
	my $ss = 0;

	for (my $i = 0; $i < 100; $i++) {
		my $tem_sum = 0; 
		for ( my $j = $ss; $j < $ss + $ip; $j++ ) {
			$tem_sum = $tem_sum + $data[$j];
		}
		my $pc = $tem_sum/$ip;
		push(@scaled,$pc);
		$ss = $ss + $ip;
	}
	
	return (\@scaled);
}
