#!/usr/bin/perl -w

	use strict;
	use POSIX qw(floor ceil);

	open(FH,"<$ARGV[0]");
	open(FHX,"$ARGV[1]");
	open(OUT,">$ARGV[2]");
	my $line_x=<FHX>;
	chomp($line_x);
	my $expr_cov = $line_x;
	
	my $line;
	my @cov;
	my $total_cov = 0;
	my $avgCov;
	my @norByCov;
	my @norByLen;

	########### storing the coverage value in an array
	while ($line=<FH>) {
		chomp($line);
		
		my @temp = split("\t",$line);
#		my @val = split("=",$temp[1]);
#		push(@cov,$val[1]);
		push(@cov,$temp[2]);
	}
	
	my $len = scalar(@cov);           ### length of the contig
	
	for (my $i = 0; $i < @cov; $i++) {
		$total_cov = $total_cov + $cov[$i];  ####### total coverage 
	}
	
	$avgCov = $total_cov/$len; ####### average coverage of the contig
                      						 
	
	######### normalization by average coverage of contig 
	for (my $i = 0; $i < @cov; $i++ ) {
		my $ratio = $cov[$i]/$avgCov;
		push(@norByCov,$ratio);	
	}
	
	############ normalization by the length of the contig and average coverage
	for (my $i = 0; $i < @norByCov; $i++) {
		my $ras_len = $norByCov[$i]/$len;
		my $nor_exp = $ras_len/$expr_cov;
		push(@norByLen,$nor_exp);
	}
	
	my @cov_ratio;

	####################### Finding the ratio of the coverage #####################
	for (my $i = 1; $i < @norByLen; $i++) {
		my $cvr;
		if ($norByLen[$i-1] == 0) {
			 if($norByLen[$i] == 0) {
				$cvr = 0;
			 } else {
				$cvr = 1;
			 }
			
		} else {
			 $cvr = $norByLen[$i]/ $norByLen[$i-1];
		}
		push(@cov_ratio,$cvr);
	}

	################ scaling of coverage value ##################################
	my $ip;
	my $fp;
	my @scaled;
	my $n = scalar(@cov_ratio);
	my $integer_val = sprintf("%1.3f", $n/100);
	($ip, $fp) = split(/\./, $integer_val);
	my $ss = 0;

	for (my $i = 0; $i < 100; $i++) {
		my $tem_sum = 0; 
		for ( my $j = $ss; $j < $ss + $ip; $j++ ) {
			$tem_sum = $tem_sum + $cov_ratio[$j];
		}
		my $pc = $tem_sum/$ip;
		push(@scaled,$pc);
		$ss = $ss + $ip;
	}
	
 	############### print scaled normalized coverage ratio #############
	for (my $i = 0; $i < @cov_ratio; $i++) {
		print OUT $i + 1,"\t",$cov_ratio[$i],"\n";
	}
	
	exit 0;


