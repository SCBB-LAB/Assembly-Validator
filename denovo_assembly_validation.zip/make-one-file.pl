open(out,">>cov-out-$ARGV[1]");#length-value

open(FH1,"normlz.$ARGV[0]");#length-wise-coverage
print out $ARGV[0];
while($line=<FH1>)
{
	chomp($line);
	@arr=split("\t",$line);
	print out "\t",$arr[1];
}
print out "\n";
