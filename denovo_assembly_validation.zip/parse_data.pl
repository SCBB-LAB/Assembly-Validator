print "Contig_ID\tLength\tCluster\n";
open(FH1,"data.txt")|| die;
while($line=<FH1>)
{
	chomp($line);
	if($line=~/length=/)
	{
		$next=<FH1>;
		chomp($next);
		@arr=split(" ",$next);
		$length=($arr[1]+1)/3;
		$next1=<FH1>;
		chomp($next1);
		@arr2=split(" ",$next1);
		$i=-1;
		open(FH2,"../combine/features-$length")|| die;
		while($line2=<FH2>)
		{
			chomp($line2);
			@arr3=split("\t",$line2);
			$i++;
			for($j=1;$j<scalar@arr2;$j++)
			{
				if($i == $j)
				{
					print $arr3[0],"\t",$length,"\t",$arr2[$j],"\n";
					last;
				}
			}
		}
	}
}
