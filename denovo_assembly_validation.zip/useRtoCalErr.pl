#!/usr/bin/perl -w
	use strict;
	open(GH,"<files_kmeans");
	
	
	my $line2;

	while ($line2=<GH>) {
		chomp($line2);
my $length=($line2*3)-1;
#print $length,"\n";
		system("Rscript script-kmeans.R combine-$line2 $length");
	}
	exit 0;
