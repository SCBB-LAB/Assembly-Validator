open(FH1,$ARGV[0]);#fasta format file
#open(out,">sequences-names");
while($line=<FH1>)
{
	chomp($line);
	if($line=~/^>/)
	{
		@arr=split(" ",$line);
		@arr2=split(">",$arr[0]);
		$next=<FH1>;
		chomp($next);
		$len=length($next);
		print $arr2[1],"\t",$len,"\n";
#		print out $arr2[1],"\n";
	}
}
	
