#!/bin/sh

#usage ./Run_Kmeans-clustering.sh <fasta file> <sam filename> <number of processors>

# download and install samtools and bedtools from https://sourceforge.net/projects/samtools/ and http://bedtools.readthedocs.org/en/latest/content/installation.html, respectively.


echo "start"
########################### set paths ########################################
#path_to_sam_format_file
path1=/path/to/sam/format
#path_to_fasta_format_file
path2=/path/to/fasta/format
#path to samtools and bedtools
path3=/path/to/samtools
path4=/path/to/bedtools

###########################################################################################################################
###################################coverage calculation ##################################
perl fasta1line.pl $path2/"$1" "$1"-1line
perl name-length.pl "$1"-1line >name-length
########### sam format file without headers ############

$path3/samtools faidx "$1"-1line
$path3/samtools import "$1"-1line.fai $path1/"$2" "$2".bam
$path3/samtools sort -@ "$3" "$2".bam "$2"-sorted
$path4/bedtools bamtobed -i "$2"-sorted.bam >align.bed
$path4/bedtools genomecov -d -i align.bed -g name-length  >genome-cov-d-opt.out
awk '{print $1}' genome-cov-d-opt.out | sort -u >sequences-names
mkdir intermediate
while read i
do
grep -w $i genome-cov-d-opt.out >intermediate/$i
done <"sequences-names"

awk '/\t1\t/{print "---"}1' genome-cov-d-opt.out >genome-cov-d-opt-new.out
perl coverage.pl genome-cov-d-opt-new.out >name-coverage
perl average-coverage.pl >experiment_coverage

#################################### lengthwise groups formation #################################

awk '{print $2}' name-length | sort | uniq -c | sort -k1rg | awk '{if($1>=5)print $2}' >lengths_5
mkdir lengths
perl create-lengthwise.pl

########################### normalized coverage calculation per base ############################
mkdir coverage

while read i
do
cd coverage
mkdir cov-$i
cd ../lengths
while read j
do
perl ../plot_cov.pl ../intermediate/$j ../experiment_coverage normlz.$j
mv normlz.$j ../coverage/cov-$i		
done < "list.$i"
cd ..
done <"lengths_5"


while read j
do
cd coverage
rm -f cov-$j/cov-out-$j
while read i
do
cd cov-$j

perl ../../make-one-file.pl $i $j
cd ..
done < "../lengths/list.$j"
perl ../add-number.pl $j cov-$j/cov-out-$j >cov-out-$j
cd ..
done <"lengths_5"

###################### normalized coverage ratio calculation #######################################
mkdir coverage-ratio
while read i
do
cd coverage-ratio
mkdir cov-$i
cd ../lengths
while read j
do
perl ../cal_cov_ratio.pl ../intermediate/$j ../experiment_coverage normlz_cr.$j
mv normlz_cr.$j ../coverage-ratio/cov-$i/normlz.$j
done <"list.$i"
cd ..
done <"lengths_5"

while read j
do
cd coverage-ratio
rm -f cov-$j/cov-out-$j
while read i
do
cd cov-$j

num=$((j-1))
perl ../../make-one-file.pl $i $j
cd ..
done < "../lengths/list.$j"
perl ../add-number.pl $num cov-$j/cov-out-$j >cov-out-$j
cd ..
done <"lengths_5"

################################# normalized maximas calculation ########################################
mkdir nor-max
while read i
do
cd nor-max
mkdir cov-$i
cd ../lengths
while read j
do
perl ../cal_max.pl ../intermediate/$j ../experiment_coverage normlz_nm.$j
mv normlz_nm.$j ../nor-max/cov-$i/normlz.$j
done <"list.$i"
cd ..
done <"lengths_5"

while read j
do
cd nor-max
rm -f cov-$j/cov-out-$j
while read i
do
cd cov-$j
perl ../../make-one-file.pl $i $j
cd ..
done < "../lengths/list.$j"
perl ../add-number.pl $j cov-$j/cov-out-$j >cov-out-$j
cd ..
done <"lengths_5"

################################### combine three features ###################################
mkdir combine
while read i
do
paste coverage/cov-out-$i coverage-ratio/cov-out-$i nor-max/cov-out-$i >combine/features-$i
done <"lengths_5"

mkdir kmeans
while read i
do
perl prepare-initial.pl $i >kmeans/combine-$i
done <"lengths_5"

################################## kmeans clustering #####################################
cd kmeans
cp ../useRtoCalErr.pl .
cp  ../script-kmeans.R .
cp ../parse_data.pl .
ls | grep combine | awk -F"-" '{print $2}' >files_kmeans
perl useRtoCalErr.pl
perl parse_data.pl >Contig_cluster.txt
cp Contig_cluster.txt ../results_with_groups
cd ..
##########################################################################################


############################# kmeans clustering along with predefined positive and negative instances ###################
mkdir kmeans_group
while read i
do
perl prepare-with-known.pl $i >kmeans_group/combine-$i
done <"lengths_5"
cd kmeans_group
cp ../useRtoCalErr.pl .
cp  ../script-kmeans.R .
cp ../parse_data_group.pl .
ls | grep combine | awk -F"-" '{print $2}' >files_kmeans
perl useRtoCalErr.pl
perl parse_data_group.pl >Contig_cluster.txt
cp Contig_cluster.txt ../results_with_known_groups
cd ..

