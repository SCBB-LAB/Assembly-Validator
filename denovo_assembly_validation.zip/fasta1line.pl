#!/usr/bin/perl


use strict;

my $usage = "\nusage: fasta1line.pl <input file (fasta format)> <output file>\n\n";

my $infile = shift or die $usage;
my $outfile = shift or die $usage;

open IN, "<$infile" or die $usage;
open OUT, ">$outfile" or die $usage;

my $header; my $sequence;
my $firstline = 1;

while (<IN>) {
  if (m/^>/) { 
    if (!$firstline) {
      print OUT $sequence."\n";
      $sequence = "";
    } 
    $firstline = 0;
    print OUT;
  }
  else {
    chomp;
    $sequence .= $_;
  } 
} 
print OUT $sequence."\n";

close IN; close OUT;


