#!/bin/sh

#download and install Reapr from <ftp://ftp.sanger.ac.uk/pub/resources/software/reapr>

# usage: ./reapr-steps.sh <fasta-file> <reads1> <reads2> <output_string> <number of processors>

#################### setting paths to reapr and other files ########################
path1=/path/to/reapr
path2=/path/to/fastafile
path3=/path/to/reads
############## running reapr ###################
$path1/reapr facheck $path2/$1 $4
$path1/reapr smaltmap $4.fa -n $5 $path3/$2 $path3/$3 $4.bam
$path1/reapr pipeline $4.fa $4.bam "$4"_output

################# reapr output parse ####################

awk '{if($3>0) print $1}' 05.summary.stats.tsv | grep -v WHOLE_ASSEMBLY | grep -v "id" | awk -F"_" '{print $1}' >reapr_with_error_contigs
awk '{if($3==0) print $1}' 05.summary.stats.tsv | grep -v WHOLE_ASSEMBLY | grep -v "id" | awk -F"_" '{print $1}' >reapr_without_error_contigs

