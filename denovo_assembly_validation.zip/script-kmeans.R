#!/usr/local/bin/Rscript --vanilla --default-packages=utils
args <- commandArgs(TRUE)
fname<-args[1]
len<- as.integer(args[2])
#sink("result.len")
sink(file="data.txt",append=TRUE);
print("length=")
print(len)
data = read.table(fname,header=T,sep="\t")
km=kmeans(data[, -(len + 1)], 2, nstart = 1,iter.max = 1000)
#print(km)

#tbl = table(data[, -(len + 1)], km$cluster)
tbl = km$cluster
print(tbl)
