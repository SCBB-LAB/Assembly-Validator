$i=0;
open(FH2,"name-length");
while($line2=<FH2>)
{
	$i++;
}close(FH2);
$sum=0;
open(FH1,"name-coverage");
while($line=<FH1>)
{
	chomp($line);
	@arr=split("\t",$line);
	$sum=$sum+$arr[1];
}
$avg=$sum/$i;
#print "$i\t$sum\t$avg\n";
print "$avg\n";

