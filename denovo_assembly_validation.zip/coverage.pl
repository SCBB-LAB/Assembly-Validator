$j=0;
open(FH1,$ARGV[0]);#genome-cov-d-opt.out
while($line=<FH1>)
{
	$sum=0;
	$i=0;
	chomp($line);
	@arr=split("\t",$line);
	$sum=$sum+$arr[2];
$j++;
	AGAIN:	do
	{$i++;
		$next=<FH1>;
		chomp($next);
		@arrx=split("\t",$next);
		$sum=$sum+$arrx[2];
		goto AGAIN if($arrx[0] eq $arr[0]);
	}
	while($next eq "---");
	print $arr[0],"\t",$sum/$i,"\n";
}
