open(FH,"lengths_5");#list of DS names
while($line=<FH>)
{
	chomp($line);
	open(out,">ds.$line");
	open(FH1,"pre/ds.$line-pre");
	while($line1=<FH1>)
	{
		chomp($line1);
		@arr=split("\t",$line1);
		print out $arr[0];
		for($i=1;$i<$line;$i++)
		{
			print out "\t",$arr[$i];
		}
		for($j=($line+1);$j<($line+$line);$j++)
		{
			print out "\t",$arr[$j];
		}
		for($i=$line+$line+1;$i<scalar@arr;$i++)
		{
			print out "\t",$arr[$i];
		}
		print  out "\n";
	}
}
