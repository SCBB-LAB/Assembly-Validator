while read i
do
cp known_instances/combine-$i known_instances_selected
done <"files_known_set_selected"
